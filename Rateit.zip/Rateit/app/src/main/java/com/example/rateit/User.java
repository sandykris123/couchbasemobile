package com.example.rateit;
import android.widget.RatingBar;


public class User {
    String sendto;
    String URL;
    String rating;
    RatingBar ratingBar;
    float ratingstars;


    public String getSendto() {
        return sendto;
    }
    public void setSendto(String sendto) {
        this.sendto = sendto;
    }

    public String getURL() {
        return URL;
    }
    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getRating() {
        return rating;
    }
    public void setRating(String rating) {
        this.rating = rating;
    }

    public float getRatingBar( ){
        //this.ratingstars = (float) ratingBar.getRating();
        return ratingstars;
    }

    public void setRatingBar(float ratingstars) { this.ratingstars =  ratingstars; }

    //public User(String sendto, String URL, String rating,RatingBar ratingBar,int ratingstars) {
    public User(String sendto, String URL, String rating, float ratingstars) {
        super();
        this.sendto = sendto;
        this.URL = URL;
        this.rating = rating;
        this.ratingBar = ratingBar;
        this.ratingstars = ratingstars;
    }

}
