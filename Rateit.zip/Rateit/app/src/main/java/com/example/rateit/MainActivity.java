package com.example.rateit;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.Toast;

import com.couchbase.lite.CouchbaseLite;
import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.DataSource;
import com.couchbase.lite.Database;
import com.couchbase.lite.DatabaseConfiguration;
import com.couchbase.lite.Dictionary;
import com.couchbase.lite.Expression;
import com.couchbase.lite.MutableDocument;
import com.couchbase.lite.Query;
import com.couchbase.lite.QueryBuilder;
import com.couchbase.lite.Result;
import com.couchbase.lite.SelectResult;

public class MainActivity extends Activity {
    ListView userList;
    UserCustomAdapter userAdapter;
    ArrayList<User> userArray = new ArrayList<User>();

    ListView RatedList;
    RatedCustomAdapter RatedAdapter;
    ArrayList<Rated> RatedArray = new ArrayList<Rated>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Context context = this;
        CouchbaseLite.init(context);


    }

    public void senddata( View view ) throws CouchbaseLiteException {
        Context context = this;
        CouchbaseLite.init(context);

        EditText sendtotext = (EditText) findViewById(R.id.sendto);
        String sendto = sendtotext.getText().toString();

        EditText URLlinktext = (EditText) findViewById(R.id.URL);
        String URLlink = URLlinktext.getText().toString();

        EditText ratingtext = (EditText) findViewById(R.id.rating);
        String rating = ratingtext.getText().toString();

        DatabaseConfiguration config = new DatabaseConfiguration();
        config.setDirectory(context.getFilesDir().getAbsolutePath());
        Database database = null;
        try {
            database = new Database("rateitdb", config);
        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }
        MutableDocument mutableDoc = new MutableDocument();
        mutableDoc.setString("type", "send");
        mutableDoc.setString("sendto", String.valueOf(sendto));
        mutableDoc.setString("from", "sandhya");
        mutableDoc.setString("to", "rangana");
        mutableDoc.setString("URL", String.valueOf(URLlink));
        mutableDoc.setString("rating", String.valueOf(rating));
        mutableDoc.setDate("createdAt", new Date());

        try {
            database.save(mutableDoc);
        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }
        Query query = QueryBuilder.select(SelectResult.all()).from(DataSource.database(database));
        //Toast.makeText(getApplicationContext(), "num rows:::"+ query.execute().allResults().size() , Toast.LENGTH_LONG).show();

        mutableDoc = new MutableDocument();
        mutableDoc.setString("type", "received");
        mutableDoc.setString("sendto", String.valueOf(sendto));
        mutableDoc.setString("from", "sandhya");
        mutableDoc.setString("to", "rangana");
        mutableDoc.setString("URL", String.valueOf(URLlink));
        mutableDoc.setString("rating", String.valueOf(rating));
        mutableDoc.setDate("createdAt", new Date());

        try {
            database.save(mutableDoc);
        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }
        query = QueryBuilder.select(SelectResult.all()).from(DataSource.database(database));
        Toast.makeText(getApplicationContext(), "num rows:::"+ query.execute().allResults().size() , Toast.LENGTH_LONG).show();


        database.close();

    }

    public void receivedata( View view ) throws CouchbaseLiteException {
        Context context = this;
        CouchbaseLite.init(context);
        userArray.clear();

        DatabaseConfiguration config = new DatabaseConfiguration();
        config.setDirectory(context.getFilesDir().getAbsolutePath());
        Database database = null;
        try { database = new Database("rateitdb", config); } catch (CouchbaseLiteException e) { e.printStackTrace(); }

        Query query = (Query) QueryBuilder.select(SelectResult.all()).from(DataSource.database(database))
                .where(Expression.property("to").equalTo(Expression.string("rangana"))
                        .and(Expression.property("type").equalTo(Expression.string("received"))));
        int numrows = query.execute().allResults().size();
        Toast.makeText(getApplicationContext(), "num rows:::"+ numrows , Toast.LENGTH_LONG).show();

        try {
            query.execute().allResults().forEach(result -> {
                Dictionary thisDocsProps = result.getDictionary(0);
                String sendto = thisDocsProps.getString("sendto").trim();
                String URL = thisDocsProps.getString("URL").trim();
                String rating = thisDocsProps.getString("rating").trim();
                float ratingstars = thisDocsProps.getFloat("ratingstars");
                int stars = (int) ratingstars;
                rating = String.valueOf(thisDocsProps.getFloat("ratingstars"));
                userArray.add(new User(sendto, URL, rating,ratingstars));
            });
        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }

        userAdapter = new UserCustomAdapter(MainActivity.this, R.layout.customlayout, userArray);
        userList = (ListView) findViewById(R.id.listView);
        userList.setItemsCanFocus(false);
        userList.setAdapter(userAdapter);

        userList.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, final int position, long id) {
                Log.i("List View Clicked", "**********");
                Toast.makeText(MainActivity.this, "List View Clicked:" + position, Toast.LENGTH_LONG).show();
            }

        });

        database.close();
    }


    public void incomingratings( View view ) throws CouchbaseLiteException {
        Context context = this;
        CouchbaseLite.init(context);
        RatedArray.clear();

        DatabaseConfiguration config = new DatabaseConfiguration();
        config.setDirectory(context.getFilesDir().getAbsolutePath());
        Database database = null;
        try { database = new Database("rateitdb", config); } catch (CouchbaseLiteException e) { e.printStackTrace(); }

        Query query = (Query) QueryBuilder.select(SelectResult.all()).from(DataSource.database(database))
                .where(Expression.property("to").equalTo(Expression.string("rangana"))
                        .and(Expression.property("type").equalTo(Expression.string("rated"))));
        int numrows = query.execute().allResults().size();
        Toast.makeText(getApplicationContext(), "num rows:::"+ numrows , Toast.LENGTH_LONG).show();

        try {
            query.execute().allResults().forEach(result -> {
                Dictionary thisDocsProps = result.getDictionary(0);
                String sendto = thisDocsProps.getString("sendto").trim();
                String URL = thisDocsProps.getString("URL").trim();
                String rating = thisDocsProps.getString("rating").trim();
                float ratingstars = thisDocsProps.getFloat("ratingstars");
                int stars = (int) ratingstars;
                rating = String.valueOf(thisDocsProps.getFloat("ratingstars"));
                RatedArray.add(new Rated(sendto, URL, rating));
            });
        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }

        RatedAdapter = new RatedCustomAdapter(MainActivity.this, R.layout.customlayoutrated, RatedArray);
        RatedList = (ListView) findViewById(R.id.ratedlistView);
        RatedList.setItemsCanFocus(false);
        RatedList.setAdapter(RatedAdapter);

        RatedList.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, final int position, long id) {
                Log.i("List View Clicked", "**********");
                Toast.makeText(MainActivity.this, "List View Clicked:" + position, Toast.LENGTH_LONG).show();
            }

        });

        database.close();
    }
}