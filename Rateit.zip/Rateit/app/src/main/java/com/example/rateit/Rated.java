package com.example.rateit;
import android.widget.RatingBar;

public class Rated {
    String sendto;
    String URL;
    String rating;
    float ratingstars;


    public String getSendto() {
        return sendto;
    }
    public void setSendto(String sendto) {
        this.sendto = sendto;
    }

    public String getURL() {
        return URL;
    }
    public void setURL(String URL) {
        this.URL = URL;
    }

    public String getRating() {
        return rating;
    }
    public void setRating(String rating) {
        this.rating = rating;
    }

    public float getRatingBar( ){
        return ratingstars;
    }

    public void setRatingBar(float ratingstars) { this.ratingstars =  ratingstars; }

    public Rated(String sendto, String URL, String rating) {
        super();
        this.sendto = sendto;
        this.URL = URL;
        this.rating = rating;

    }

}
