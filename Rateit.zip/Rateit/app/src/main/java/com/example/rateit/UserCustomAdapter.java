package com.example.rateit;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.DataSource;
import com.couchbase.lite.Database;
import com.couchbase.lite.DatabaseConfiguration;
import com.couchbase.lite.Dictionary;
import com.couchbase.lite.Expression;
import com.couchbase.lite.Meta;
import com.couchbase.lite.MutableDocument;
import com.couchbase.lite.QueryBuilder;
import com.couchbase.lite.Result;
import com.couchbase.lite.ResultSet;
import com.couchbase.lite.SelectResult;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;


public class UserCustomAdapter extends ArrayAdapter<User> {
    Context context;
    int layoutResourceId;
    ArrayList<User> data = new ArrayList<User>();

    public UserCustomAdapter(Context context, int layoutResourceId,
                             ArrayList<User> data) {
        super(context, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        UserHolder holder = null;

        if (row == null) {
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);
            holder = new UserHolder();
            holder.from = (TextView) row.findViewById(R.id.textView1);
            holder.URL = (TextView) row.findViewById(R.id.textView2);
            holder.rating = (TextView) row.findViewById(R.id.textView3);
            holder.ratingBar = (RatingBar) row.findViewById(R.id.ratingBar);
            holder.btnRate = (Button) row.findViewById(R.id.ratebutton);
            holder.btnDelete = (Button) row.findViewById(R.id.deletebutton);
            row.setTag(holder);
        } else {
            holder = (UserHolder) row.getTag();
        }
        User user = data.get(position);
        holder.from.setText(user.getSendto());
        holder.URL.setText(user.getURL());
        holder.rating.setText(user.getRating());
        holder.ratingBar.setNumStars((int) user.getRatingBar());
        //RatingBar ratingBar = (RatingBar) convertView.findViewById(R.id.ratingBar);

        holder.btnRate.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //Log.i("Edit Button Clicked", "**********");
                //Toast.makeText(context, "Edit button Clicked", Toast.LENGTH_LONG).show();
                DatabaseConfiguration config = new DatabaseConfiguration();
                config.setDirectory(context.getFilesDir().getAbsolutePath());
                Database database = null;
                try { database = new Database("rateitdb", config); } catch (CouchbaseLiteException e) { e.printStackTrace(); }
                MutableDocument mutableDoc = new MutableDocument();
                mutableDoc.setString("type", "rated");
                mutableDoc.setString("from", "sandhya");
                mutableDoc.setString("to", "rangana");
                mutableDoc.setString("sendto", user.getSendto());
                mutableDoc.setString("URL", user.getURL());
                mutableDoc.setString("rating", user.getRating());
                float stars = user.getRatingBar();
                Toast.makeText(context, "Rating Stars" + stars, Toast.LENGTH_LONG).show();
                mutableDoc.setFloat("ratingstars", user.getRatingBar());
                mutableDoc.setDate("createdAt", new Date());

                try {
                    database.save(mutableDoc);
                } catch (CouchbaseLiteException e) {
                    e.printStackTrace();
                }


            }
        });

        holder.btnDelete.setOnClickListener(new OnClickListener() {

            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                //Log.i("Delete Button Clicked", "**********");
                //Toast.makeText(context, "Delete button Clicked"+user.getSendto(), Toast.LENGTH_LONG).show();

                DatabaseConfiguration config = new DatabaseConfiguration();
                config.setDirectory(context.getFilesDir().getAbsolutePath());
                Database database = null;
                try { database = new Database("rateitdb", config); } catch (CouchbaseLiteException e) { e.printStackTrace(); }


                try {
                    ResultSet rs = QueryBuilder.select(SelectResult.expression(Meta.id)).from(DataSource.database(database))
                            .where(Expression.property("sendto").equalTo(Expression.string(user.getSendto()))
                            .and(Expression.property("type").equalTo(Expression.string("received"))))
                            .execute();

                    //Toast.makeText(context, "num rows:::"+ rs.allResults().size() , Toast.LENGTH_LONG).show();
                    for (Result result : rs) {
                        Dictionary all = result.getDictionary("rateitdb");
                        //Toast.makeText(context, "num rows:::"+ all.getString("id"), Toast.LENGTH_LONG).show();
                        //Toast.makeText(context, "num rows:::"+result.getString("id"), Toast.LENGTH_LONG).show();
                        //Instant ttl = Instant.now().plus(1, ChronoUnit.DAYS);
                        //Instant fiveMinutesFromNow = Instant.now().plus(5, ChronoUnit.MINUTES);
                        //Instant ttl  = Instant.now().plus(5, ChronoUnit.SECONDS);
                        Date date = new Date();
                        //This method returns the time in millis
                        long timeMilli = date.getTime();
                        //database.setDocumentExpiration(result.getString("id"), null);
                        database.setDocumentExpiration(result.getString("id"), new Date(timeMilli));
                        Toast.makeText(context, "doc id:::"+ result.getString("id"), Toast.LENGTH_LONG).show();
                    }
                    //database.setDocumentExpiration(result.getString("id") , new Date(ttl.toEpochMilli()));

                } catch (CouchbaseLiteException e) {
                    e.printStackTrace();
                }
                //Query query = QueryBuilder.select(SelectResult.all()).from(DataSource.database(database));
                //Toast.makeText(context, "Delete button Clicked"+user.getSendto(), Toast.LENGTH_LONG).show();

            }
        });

        holder.ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                User item = getItem(position);
                assert item != null;
                //float stars = item.getRatingBar();
                float stars = ratingBar.getRating();
                item.setRatingBar(stars);
                Toast.makeText(context, "Rating Stars" + stars, Toast.LENGTH_LONG).show();
            }
        });

        return row;

    }

    static class UserHolder {
        TextView from;
        TextView URL;
        TextView rating;
        RatingBar ratingBar;
        //int ratingstars;
        Button btnRate;
        Button btnDelete;
    }
}


