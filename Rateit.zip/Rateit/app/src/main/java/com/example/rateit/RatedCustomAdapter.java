package com.example.rateit;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.DataSource;
import com.couchbase.lite.Database;
import com.couchbase.lite.DatabaseConfiguration;
import com.couchbase.lite.Dictionary;
import com.couchbase.lite.Expression;
import com.couchbase.lite.Meta;
import com.couchbase.lite.MutableDocument;
import com.couchbase.lite.QueryBuilder;
import com.couchbase.lite.Result;
import com.couchbase.lite.ResultSet;
import com.couchbase.lite.SelectResult;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;

public class RatedCustomAdapter extends ArrayAdapter<Rated> {
    Context context;
    int layoutResourceId;
    ArrayList<Rated> data = new ArrayList<Rated>();

    public RatedCustomAdapter(Context context, int layoutResourceId, ArrayList<Rated> data) {
        super(context, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;
    }


    @Override
    public View getView( int position, View convertView, ViewGroup parent) {
        View row = convertView;
        RatedHolder Ratedholder = null;

        if (row == null) {
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);
            Ratedholder = new RatedHolder();
            Ratedholder.from = (TextView) row.findViewById(R.id.from);
            Ratedholder.URL = (TextView) row.findViewById(R.id.subject);
            Ratedholder.rating = (TextView) row.findViewById(R.id.rating);
            Ratedholder.btnDelete = (Button) row.findViewById(R.id.deleteratingbutton);
            row.setTag(Ratedholder);
        } else {
            Ratedholder = (RatedHolder) row.getTag();
        }
        Rated user = data.get(position);
        Ratedholder.from.setText(user.getSendto());
        Ratedholder.URL.setText(user.getURL());
        Ratedholder.rating.setText(user.getRating());


        Ratedholder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                //Log.i("Delete Button Clicked", "**********");
                //Toast.makeText(context, "Delete button Clicked"+user.getSendto(), Toast.LENGTH_LONG).show();

                DatabaseConfiguration config = new DatabaseConfiguration();
                config.setDirectory(context.getFilesDir().getAbsolutePath());
                Database database = null;
                try { database = new Database("rateitdb", config); } catch (CouchbaseLiteException e) { e.printStackTrace(); }

                try {
                    ResultSet rs = QueryBuilder.select(SelectResult.expression(Meta.id)).from(DataSource.database(database))
                            .where(Expression.property("sendto").equalTo(Expression.string(user.getSendto()))
                                    .and(Expression.property("type").equalTo(Expression.string("rated"))))
                            .execute();
                    for (Result result : rs) {
                        Dictionary all = result.getDictionary("rateitdb");
                        Date date = new Date();
                        //This method returns the time in millis
                        long timeMilli = date.getTime();
                        database.setDocumentExpiration(result.getString("id"), new Date(timeMilli));
                        Toast.makeText(context, "doc id:::"+ result.getString("id"), Toast.LENGTH_LONG).show();
                    }
                } catch (CouchbaseLiteException e) {
                    e.printStackTrace();
                }
            }
        });
        return row;

    }

    static class RatedHolder {
        TextView from;
        TextView URL;
        TextView rating;
        Button btnDelete;
    }
}


